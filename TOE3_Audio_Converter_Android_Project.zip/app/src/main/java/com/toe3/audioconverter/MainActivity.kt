package com.toe3.audioconverter

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import java.io.InputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var selected: TextView
    private var selectedUri: Uri? = null
    private var selectedName: String = ""
    private val pickFile = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16,24,39)
        window.navigationBarColor = android.graphics.Color.rgb(16,24,39)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(245,247,251))
        }
        val title = TextView(this).apply {
            text = "TOE3 Audio Converter"
            textSize = 24f; setTextColor(0xFF111827.toInt()); setTypeface(null, 1)
        }
        val subtitle = TextView(this).apply {
            text = "เครื่องมือจัดการไฟล์เสียง FSB5 / RESOURCE"
            textSize = 14f; setTextColor(0xFF64748B.toInt())
        }
        root.addView(title)
        root.addView(subtitle, margin(0, 6, 0, 22))

        val choose = button("เลือกไฟล์จากเครื่อง") { openPicker() }
        root.addView(choose, matchWrap())
        selected = TextView(this).apply {
            text = "ยังไม่ได้เลือกไฟล์"
            textSize = 14f; setTextColor(0xFF334155.toInt())
            setPadding(12, 14, 12, 14)
        }
        root.addView(selected, matchWrap())

        val decode = button("RESOURCE / FSB5  →  WAV") {
            selectedUri?.let { inspectFile(it, true) } ?: message("กรุณาเลือกไฟล์ก่อน")
        }
        root.addView(decode, margin(0, 12, 0, 8))
        val encode = button("WAV  →  FSB5 / RESOURCE") {
            selectedUri?.let { inspectFile(it, false) } ?: message("กรุณาเลือกไฟล์ก่อน")
        }
        root.addView(encode, margin(0, 0, 0, 12))

        status = TextView(this).apply {
            text = "สถานะ: พร้อมใช้งาน\n\nต้นแบบนี้ตรวจชนิดไฟล์และอ่านข้อมูล WAV/FSB5 เบื้องต้นได้"
            textSize = 14f; setTextColor(0xFF334155.toInt())
            setPadding(14, 16, 14, 16)
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        root.addView(status, matchWrap())
        val note = TextView(this).apply {
            text = "\nหมายเหตุ: ยังไม่ได้ฝังเอนจินถอดรหัส/เข้ารหัส FMOD FSB5 จึงยังไม่สร้างไฟล์เสียงแปลงจริง และจะไม่สร้างไฟล์ปลอมที่เกมเปิดไม่ได้"
            textSize = 12f; setTextColor(0xFFB45309.toInt())
        }
        root.addView(note, matchWrap())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, pickFile)
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedUri = uri
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                selectedName = queryName(uri)
                selected.text = "ไฟล์ที่เลือก: $selectedName"
                status.text = "เลือกไฟล์แล้ว\nกดปุ่มแปลงเพื่อวิเคราะห์ชนิดไฟล์"
            }
        }
    }

    private fun queryName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "unknown"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    private fun inspectFile(uri: Uri, decode: Boolean) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: byteArrayOf()
            val header = String(bytes.take(4).map { it.toInt().toChar() }.toCharArray())
            val isWav = header == "RIFF" && bytes.size >= 12 &&
                String(bytes.sliceArray(8..11).map { it.toInt().toChar() }.toCharArray()) == "WAVE"
            val isFsb = header == "FSB5"
            val size = bytes.size
            val details = when {
                isWav -> {
                    val channels = u16(bytes, 22)
                    val sampleRate = u32(bytes, 24)
                    val bits = u16(bytes, 34)
                    "ตรวจพบ WAV\nขนาด: $size bytes\nChannels: $channels\nSample rate: $sampleRate Hz\nBits per sample: $bits"
                }
                isFsb -> "ตรวจพบ FSB5 (FMOD Sound Bank)\nขนาด: $size bytes\n\nไฟล์นี้มี signature FSB5 แต่ต้องใช้ตัวถอดรหัสที่รองรับ bank/codec และ metadata ของเกม"
                else -> "ยังระบุชนิดไฟล์ไม่ได้\nขนาด: $size bytes\nHeader: ${bytes.take(8).joinToString(" ") { "%02X".format(it) }}"
            }
            status.text = details + if (decode)
                "\n\nผลการแปลง: ยังไม่เริ่ม เพราะแอปต้นแบบยังไม่มี FMOD/vgmstream decoder"
            else
                "\n\nผลการแปลง: ยังไม่เริ่ม เพราะการสร้าง FSB5 ที่ใช้ได้ต้องมี encoder และ metadata ที่ตรงกับเกม"
        } catch (e: Exception) {
            status.text = "อ่านไฟล์ไม่สำเร็จ: ${e.message}"
        }
    }

    private fun u16(b: ByteArray, p: Int) = if (b.size >= p + 2) (b[p].toInt() and 255) or ((b[p+1].toInt() and 255) shl 8) else 0
    private fun u32(b: ByteArray, p: Int): Long = if (b.size >= p + 4)
        (b[p].toLong() and 255) or ((b[p+1].toLong() and 255) shl 8) or
        ((b[p+2].toLong() and 255) shl 16) or ((b[p+3].toLong() and 255) shl 24) else 0L

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setOnClickListener { action() }
    }
    private fun message(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun margin(l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(l, t, r, b)
    }
}
