# TOE3 Audio Converter — Android prototype

## What this project currently does
- Android file picker for `.resource`, `.bank`, `.fsb`, `.wav`, and other files.
- Detects a standard RIFF/WAVE header and reads basic WAV format fields.
- Detects the `FSB5` magic header.
- Shows clear status instead of pretending a conversion succeeded.

## Important limitation
This is an honest UI/prototype, **not yet a working FSB5 converter**. FSB5 is a structured FMOD bank format. A valid converter needs a compatible decoder/encoder and, for replacing TOE3 audio, the exact bank layout, codec settings, sample metadata, and any companion metadata used by the game. Merely writing the `FSB5` header or renaming WAV to `.resource` will not work.

## Build
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync.
3. Build > Build APK(s).

The resulting APK is a prototype for file selection and format inspection. Do not use it to overwrite game files.
